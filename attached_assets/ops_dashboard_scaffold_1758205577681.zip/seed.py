#!/usr/bin/env python3
import sqlite3, csv, sys, os
DB = os.environ.get("DB_PATH", "ops.db")
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.executescript(open("schema.sql").read())
with open("seed.csv", newline="") as f:
    rdr = csv.DictReader(f)
    rows = [tuple(r.get(k) for k in rdr.fieldnames) for r in rdr]
    placeholders = ",".join(["?"]*len(rdr.fieldnames))
    cur.executemany(f"INSERT INTO requests ({','.join(rdr.fieldnames)}) VALUES ({placeholders})", rows)
conn.commit()
print(f"Seeded {len(rows)} rows into {DB}")
