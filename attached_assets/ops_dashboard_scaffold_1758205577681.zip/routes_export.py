# routes_export.py
from fastapi import APIRouter, Query
from fastapi.responses import StreamingResponse
from typing import List, Optional
import sqlite3, os, io, csv, pandas as pd

router = APIRouter()
DB = os.environ.get("DB_PATH", "ops.db")

def _connect():
    conn = sqlite3.connect(DB, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def _in_clause(values, field):
    if not values: 
        return ""
    placeholders = ",".join(["?"]*len(values))
    return f" AND {field} IN ({placeholders}) "

def _binds(from_ts,to_ts,departments,statuses,assignees):
    binds=[from_ts,to_ts]
    for group in (departments or []), (statuses or []), (assignees or []):
        binds.extend(group)
    return binds

BASE = " FROM requests WHERE created_at >= ? AND created_at < ? "

@router.get("/export/requests.csv")
def export_csv(from_ts:str, to_ts:str, departments: Optional[List[str]] = Query(None),
               statuses: Optional[List[str]] = Query(None), assignees: Optional[List[str]] = Query(None)):
    conn=_connect(); cur=conn.cursor()
    where = BASE + _in_clause(departments,"department") + _in_clause(statuses,"status") + _in_clause(assignees,"assignee")
    sql = "SELECT id, department, team, type, status, assignee, created_at, started_at, first_response_at, completed_at, updated_at " + where + " ORDER BY created_at DESC"
    cur.execute(sql, _binds(from_ts,to_ts,departments,statuses,assignees))
    rows = [dict(r) for r in cur.fetchall()]
    output = io.StringIO()
    if rows:
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    else:
        output.write("")
    output.seek(0)
    return StreamingResponse(output, media_type="text/csv",
        headers={"Content-Disposition":"attachment; filename=requests.csv"})

@router.get("/export/requests.xlsx")
def export_xlsx(from_ts:str, to_ts:str, departments: Optional[List[str]] = Query(None),
               statuses: Optional[List[str]] = Query(None), assignees: Optional[List[str]] = Query(None)):
    conn=_connect(); cur=conn.cursor()
    where = BASE + _in_clause(departments,"department") + _in_clause(statuses,"status") + _in_clause(assignees,"assignee")
    sql = "SELECT id, department, team, type, status, assignee, created_at, started_at, first_response_at, completed_at, updated_at " + where + " ORDER BY created_at DESC"
    cur.execute(sql, _binds(from_ts,to_ts,departments,statuses,assignees))
    rows = [dict(r) for r in cur.fetchall()]
    df = pd.DataFrame(rows)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as writer:
        (df if not df.empty else pd.DataFrame()).to_excel(writer, index=False, sheet_name="Requests")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition":"attachment; filename=requests.xlsx"})
