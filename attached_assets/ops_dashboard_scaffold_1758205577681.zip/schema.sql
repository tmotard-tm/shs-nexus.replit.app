-- SQLite schema for Requests table
DROP TABLE IF EXISTS requests;
CREATE TABLE requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  department TEXT,
  team TEXT,
  type TEXT,
  status TEXT,
  assignee TEXT,
  created_at TEXT,        -- ISO8601 timestamp
  started_at TEXT,        -- ISO8601 timestamp
  first_response_at TEXT, -- ISO8601 timestamp
  completed_at TEXT,      -- ISO8601 timestamp
  updated_at TEXT         -- ISO8601 timestamp
);

CREATE INDEX IF NOT EXISTS idx_requests_created_at ON requests (created_at);
CREATE INDEX IF NOT EXISTS idx_requests_department ON requests (department);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests (status);
CREATE INDEX IF NOT EXISTS idx_requests_assignee ON requests (assignee);
CREATE INDEX IF NOT EXISTS idx_requests_completed_at ON requests (completed_at);
