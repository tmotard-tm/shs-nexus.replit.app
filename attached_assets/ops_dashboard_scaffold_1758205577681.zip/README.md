# Operations Dashboard (Replit-ready)

Single project with FastAPI API + static front-end and SQLite DB.

## Run locally / Replit
1) **Install deps**
```
pip install -r requirements.txt
```
2) **Seed demo data**
```
python seed.py
```
> By default this creates/uses `ops.db` in the project root.

3) **Start the server**
```
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Open: http://localhost:8000

## What’s included
- **/metrics** — returns summary, by_type, by_team, by_user, and per-agent daily completions.  
- **/export/requests.csv** and **/export/requests.xlsx** — export rows matching current filters.  
- Static dashboard (`/`) with filters (date range, department, status, assignee text search), tiles, tables, and export buttons.

## NTAO Label
The UI shows the corrected label: **NTAO — National Truck Assortment**. Update your data source descriptions similarly if needed.

## Environment
- SQLite file path can be changed via `DB_PATH` env variable.
