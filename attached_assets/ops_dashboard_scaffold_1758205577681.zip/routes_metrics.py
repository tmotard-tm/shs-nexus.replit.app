# routes_metrics.py
from fastapi import APIRouter, Query
from typing import List, Optional, Dict, Any
import sqlite3, os, itertools, datetime as dt

router = APIRouter()
DB = os.environ.get("DB_PATH", "ops.db")

def _connect():
    conn = sqlite3.connect(DB, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def _in_clause(values: Optional[List[str]], field: str) -> str:
    if not values: 
        return ""
    placeholders = ",".join(["?"]*len(values))
    return f" AND {field} IN ({placeholders}) "

def _binds(from_ts:str, to_ts:str, departments, statuses, assignees):
    binds = [from_ts, to_ts]
    for group in (departments or []), (statuses or []), (assignees or []):
        binds.extend(group)
    return binds

@router.get("/metrics")
def metrics(
    from_ts: str = Query(..., description="ISO8601 inclusive start"),
    to_ts: str   = Query(..., description="ISO8601 exclusive end"),
    departments: Optional[List[str]] = Query(None),
    statuses: Optional[List[str]]    = Query(None),
    assignees: Optional[List[str]]   = Query(None),
):
    conn = _connect()
    cur = conn.cursor()

    # Build WHERE
    where = " WHERE created_at >= ? AND created_at < ? "
    where += _in_clause(departments, "department")
    where += _in_clause(statuses, "status")
    where += _in_clause(assignees, "assignee")

    # Summary with aging buckets (hours via strftime)
    summary_sql = f"""
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status IN ('Pending','Open','New') THEN 1 ELSE 0 END) AS pending,
      SUM(CASE WHEN status IN ('In Progress','Assigned') THEN 1 ELSE 0 END) AS in_progress,
      SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed,
      SUM(CASE WHEN status IN ('Canceled','Cancelled') THEN 1 ELSE 0 END) AS canceled,
      ROUND(AVG(
        CASE WHEN completed_at IS NOT NULL 
          THEN (strftime('%s', completed_at) - strftime('%s', created_at))/3600.0
        END
      ), 2) AS avg_created_to_done,
      ROUND(AVG(
        CASE WHEN started_at IS NOT NULL AND completed_at IS NOT NULL
          THEN (strftime('%s', completed_at) - strftime('%s', started_at))/3600.0
        END
      ), 2) AS avg_start_to_done,
      ROUND(AVG(
        CASE WHEN first_response_at IS NOT NULL
          THEN (strftime('%s', first_response_at) - strftime('%s', created_at))/3600.0
        END
      ), 2) AS avg_first_response,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 BETWEEN 0 AND 48 THEN 1 ELSE 0 END) AS age_0_2d,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 BETWEEN 72 AND 168 THEN 1 ELSE 0 END) AS age_3_7d,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 BETWEEN 192 AND 336 THEN 1 ELSE 0 END) AS age_8_14d,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 BETWEEN 360 AND 720 THEN 1 ELSE 0 END) AS age_15_30d,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 BETWEEN 744 AND 1440 THEN 1 ELSE 0 END) AS age_31_60d,
      SUM(CASE WHEN status <> 'Completed' AND (strftime('%s','now') - strftime('%s', created_at))/3600.0 > 1440 THEN 1 ELSE 0 END) AS age_gt_60d
    FROM requests
    {where};
    """

    # By type
    by_type_sql = f"""
    SELECT type, COUNT(*) AS total
    FROM requests
    {where}
    GROUP BY type ORDER BY total DESC;
    """

    # By team
    by_team_sql = f"""
    SELECT COALESCE(team,'(Unassigned Team)') AS team,
      COUNT(*) AS total,
      SUM(CASE WHEN status IN ('In Progress','Assigned') THEN 1 ELSE 0 END) AS in_progress,
      SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed,
      ROUND(AVG(CASE WHEN completed_at IS NOT NULL THEN (strftime('%s', completed_at) - strftime('%s', created_at))/3600.0 END), 2) AS avg_created_to_done,
      ROUND(AVG(CASE WHEN started_at   IS NOT NULL AND completed_at IS NOT NULL THEN (strftime('%s', completed_at) - strftime('%s', started_at))/3600.0 END), 2) AS avg_start_to_done
    FROM requests
    {where}
    GROUP BY COALESCE(team,'(Unassigned Team)')
    ORDER BY total DESC;
    """

    # By user
    by_user_sql = f"""
    SELECT COALESCE(assignee,'(Unassigned)') AS assignee,
      COUNT(*) AS total,
      SUM(CASE WHEN status IN ('In Progress','Assigned') THEN 1 ELSE 0 END) AS in_progress,
      SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed,
      ROUND(AVG(CASE WHEN completed_at IS NOT NULL THEN (strftime('%s', completed_at) - strftime('%s', created_at))/3600.0 END), 2) AS avg_created_to_done,
      ROUND(AVG(CASE WHEN started_at   IS NOT NULL AND completed_at IS NOT NULL THEN (strftime('%s', completed_at) - strftime('%s', started_at))/3600.0 END), 2) AS avg_start_to_done
    FROM requests
    {where}
    GROUP BY COALESCE(assignee,'(Unassigned)')
    ORDER BY total DESC;
    """

    # Completed per day by agent
    completed_ts_sql = f"""
    SELECT date(completed_at) AS day,
           COALESCE(assignee,'(Unassigned)') AS assignee,
           COUNT(*) AS completed_count,
           ROUND(AVG((strftime('%s', completed_at) - strftime('%s', created_at))/3600.0), 2) AS avg_hrs_created_to_done
    FROM requests
    {where} AND completed_at IS NOT NULL
    GROUP BY date(completed_at), COALESCE(assignee,'(Unassigned)')
    ORDER BY day, assignee;
    """

    binds = _binds(from_ts, to_ts, departments, statuses, assignees)

    cur.execute(summary_sql, binds)
    summary = dict(cur.fetchone() or {})

    cur.execute(by_type_sql, binds)
    by_type = [dict(r) for r in cur.fetchall()]

    cur.execute(by_team_sql, binds)
    by_team = [dict(r) for r in cur.fetchall()]

    cur.execute(by_user_sql, binds)
    by_user = [dict(r) for r in cur.fetchall()]

    cur.execute(completed_ts_sql, binds)
    completed_time_series = [dict(r) for r in cur.fetchall()]

    return {
        "summary": summary,
        "by_type": by_type,
        "by_team": by_team,
        "by_user": by_user,
        "completed_time_series": completed_time_series
    }
